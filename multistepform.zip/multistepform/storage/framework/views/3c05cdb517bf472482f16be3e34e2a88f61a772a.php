<!DOCTYPE html>
<html>
<head>
    <title>Multi Step Form</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body style="background-color: #f3fdf3">

<div class="container">
    <h2>Multi Step Form </h2>
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>

</html>
<?php /**PATH C:\xampp1\htdocs\multistepform\resources\views/layout/default.blade.php ENDPATH**/ ?>